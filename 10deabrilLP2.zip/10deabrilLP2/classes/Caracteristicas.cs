﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10deabrilLP2.classes
{
    internal class Caracteristicas
    {
        private string nome;
        private int idade;
        private int altura;

        public string Nome{ get { return nome; } set { nome = value; } }
        public int Idade{ get { return idade; } set { idade = value; } }
        public int Altura{ get { return altura; } set { altura = value; } }

    }
}
