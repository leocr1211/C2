﻿using _10deabrilLP2.classes;
namespace encapsulamentoeabstracao;
class Program
{
    public static void Main(string[] args)
    {
        Caracteristicas usuario = new Caracteristicas();

        usuario.Nome = "Leonardo";
        usuario.Idade = 20;
        usuario.Altura = 180;

        Console.WriteLine(usuario.Nome + " " + usuario.Idade + " " + usuario.Altura);
    }
}