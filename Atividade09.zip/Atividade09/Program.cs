﻿using Atividade09.Atividade09;
using System.Reflection.Metadata;

namespace atividade;
class Program
{
    public static void Main(string[] args)
    {
        ProgramaAtividade09.Executar();
    }
}