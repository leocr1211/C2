﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atividade09.pastadasclasses
{
    namespace Atividade09.pastadasclasses
    {
        public class Animal
        {
            // Protected permite que as classes filhas acessem diretamente
            protected string Reino { get; set; }
            protected string Filo { get; set; }
            protected string Classe { get; set; }
            protected string Ordem { get; set; }
            protected string Familia { get; set; }
            protected string Genero { get; set; }
            protected string Especie { get; set; }
            protected bool[] Continente { get; set; }

            public Animal(string reino, string filo, string classe, string ordem, string familia, string genero, string especie, bool[] continente)
            {
                this.Reino = reino;
                this.Filo = filo;
                this.Classe = classe;
                this.Ordem = ordem;
                this.Familia = familia;
                this.Genero = genero;
                this.Especie = especie;
                this.Continente = continente;
            }

            public string GetEspecie() => Especie;
            public string GetReino() => Reino;
            public bool[] GetContinente() => Continente;
        }
    
    }
}
