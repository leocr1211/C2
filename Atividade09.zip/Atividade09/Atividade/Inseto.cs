﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atividade09.Atividade09
{
        public class Inseto : Artropode
        {
            protected bool VetorDoenca { get; set; }
            protected string[] DoencasTransmitidas { get; set; }

            public Inseto(string reino, string filo, string classe, string ordem, string familia, string genero, string especie, bool[] continente, int paresDePatas, bool vetorDoenca, string[] doencas)
                : base(reino, filo, classe, ordem, familia, genero, especie, continente, paresDePatas)
            {
                this.VetorDoenca = vetorDoenca;
                this.DoencasTransmitidas = doencas;
            }

            public bool GetVetorDoenca() => VetorDoenca;
            public string[] GetDoencas() => DoencasTransmitidas;
        }
}
