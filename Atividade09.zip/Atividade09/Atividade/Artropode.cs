﻿using Atividade09.pastadasclasses.Atividade09.pastadasclasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atividade09.Atividade09
{
        public class Artropode : Animal
        {
            protected int ParesDePatas { get; set; }

            public Artropode(string reino, string filo, string classe, string ordem, string familia, string genero, string especie, bool[] continente, int paresDePatas)
                : base(reino, filo, classe, ordem, familia, genero, especie, continente)
            {
                this.ParesDePatas = paresDePatas;
            }

            public int GetParesDePatas() => ParesDePatas;
        }
}

