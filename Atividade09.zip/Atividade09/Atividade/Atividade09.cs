﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atividade09.Atividade09
{
        public class ProgramaAtividade09
        {
            public static void Executar()
            {
                bool[] continentesAedes = new bool[5] { true, true, true, false, true };
                string[] doencas = new string[4] { "Dengue", "Zika", "Chikungunya", "Febre Amarela" };

                Inseto aedesAegypti = new Inseto("Animalia", "Arthropoda", "Insecta", "Diptera", "Culicidae", "Aedes", "Aedes aegypti", continentesAedes, 3, true, doencas);

                Console.WriteLine("DADOS DO INSETO");
                Console.WriteLine($"Espécie: {aedesAegypti.GetEspecie()}");
                Console.WriteLine($"Reino:   {aedesAegypti.GetReino()}");
                Console.WriteLine($"Patas:   {aedesAegypti.GetParesDePatas()} pares");
                Console.WriteLine($"Vetor:   {(aedesAegypti.GetVetorDoenca() ? "Sim" : "Não")}");

                Console.WriteLine("\nDoenças Transmitidas:");
                foreach (string d in aedesAegypti.GetDoencas())
                {
                    Console.WriteLine($"- {d}");
                }

                Console.WriteLine("\nOcorrência por Continente:");
                string[] nomes = { "África", "América", "Ásia", "Europa", "Oceania" };
                for (int i = 0; i < 5; i++)
                {
                    if (aedesAegypti.GetContinente()[i])
                    {
                        Console.WriteLine($"- Encontrado na {nomes[i]}");
                    }
                }


            }
        }
 
}
